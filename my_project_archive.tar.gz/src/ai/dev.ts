
import { config } from 'dotenv';
config();

import '@/ai/flows/accent-improvement-suggestions.ts';
import '@/ai/flows/ai-tutor-chat-flow.ts'; // Add the new chat flow
